# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

## Colors

### Primary

- Dark Gray: hsl(0, 0%, 63%)
- Black: hsl(0, 0%, 0%)
- White: hsl(0, 0%, 100%)
- Very Dark Gray: hsl(0, 0%, 27%)

## Typography

### Body Copy

- Font size: 12px

### Font

- Family: [Spartan](https://fonts.google.com/specimen/Spartan)
- Weights: 500, 600, 700
